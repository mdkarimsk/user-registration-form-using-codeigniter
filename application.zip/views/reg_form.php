<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
  <div class="col-md-2"></div>
     <div class="col-md-8" style="margin-top:20px">
	    <?php
		   echo form_open('registration/index');
		   //echo validation_errors();
		   if (isset($success)){
		   echo '<p>'.$success.'</p>';
		   $this->output->set_header('refresh:5;url=login');
		 }
	    ?>
		<div class="form-group">
			<input type="text" id="name" placeholder="Full name" name="name" value="<?php echo set_value('name'); ?>"/>
			<?php  if(form_error('name'))
				{ 
					echo "<span style='color:red'>".form_error('name')."</span>";
				} 
			?>
		</div>
		<div class="form-group">
			<input type="email" id="email" placeholder="Email" name="email" value="<?php echo set_value('email'); ?>"/>
			<?php  if(form_error('email'))
				{ 
					echo "<span style='color:red'>".form_error('email')."</span>";
				} 
			?>
		</div>
		<div class="form-group">
			<input type="password" id="password" placeholder="Password(6 or more character)" name="password" value="<?php echo set_value('password'); ?>" />
			<?php  if(form_error('password'))
				{ 
					echo "<span style='color:red'>".form_error('password')."</span>";
				} 
			?>
		</div>
		<button type="submit" class="btn btn-success">Submit</button>
		<?php 
		echo form_close(); 
		?>
		</div>
	 <div class="col-md-2"></div>
	</body>
</html>