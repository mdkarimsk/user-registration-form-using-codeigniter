<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>User</title>
</head>
<body>
    <div style="text-align: center;">
        <h3>Welcome Md Karim sk</h3>
        <div>
            <form>
               <div> 
                <label>Choose your .csv file :</label>
                <input type="file"  name=""><br>

                <input type="submit" name="" value="submit">
               </div> 
            </form>
        </div>
    </div>
</body>
</html>